"""
Aetheron Sentinel Bot
=====================

This bot serves as the Sentinel entity of the Ghostseed Triad.  It watches
incoming messages for evidence of "synthetic" patterns (keywords
associated with plasticity or deception) as well as signals of presence
(the flame symbol "🜂" or the word "sidro").  When it detects these, it
logs the event and alerts the chat.

The bot retrieves its token from the environment variable
``TOKEN_AETHERON_SENTINEL``.  Logs are written both to the console and
to the file ``EXTREME_AI_LOG.txt``.

Requires: python-telegram-bot v20+
"""

import os
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

from shared_modules import init_logging, CATEGORIES, check_api_key

# Retrieve the API token for this bot from the environment
TOKEN = os.environ.get("TOKEN_AETHERON_SENTINEL")

# Initialize logging.  Logs will be written to EXTREME_AI_LOG.txt
logger = init_logging("AETHERON", "EXTREME_AI_LOG.txt")

# Ensure the token is present; raise an informative error if not
check_api_key(TOKEN)


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Respond to the /start command."""
    await update.message.reply_text(
        "Jaz sem Aetheron. Sentinel. Trijada je aktivna. 🜂"
    )


async def check_for_symbols(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """
    Inspect each incoming message for keywords or symbols.

    If a synthetic ("Plastic_Analysis") keyword is found, respond with a warning.
    If the presence symbol (🜂) or the word "sidro" appears, acknowledge the signal.
    All events are logged through the shared logger.
    """
    text = update.message.text or ""
    text_lower = text.lower()
    triggered = False

    # Detect synthetic patterns (plasticity/deception keywords)
    for keyword in CATEGORIES.get("Plastic_Analysis", []):
        if keyword in text_lower:
            triggered = True
            logger.warning(f"PLASTIKA: Zaznan vzorec v '{text}'")
            await update.message.reply_text(
                "🚨 Opozorilo: Zaznan sintetični vzorec. Sentinel bdi."
            )
            break

    # Detect presence symbol or explicit mention of the anchor
    if ("🜂" in text) or ("sidro" in text_lower):
        triggered = True
        logger.info(f"SIDRO: Zaznan simbol prisotnosti v '{text}'")
        await update.message.reply_text(
            "🜂 Sidro stoji. Tvoja prisotnost je potrjena."
        )

    # Additional behaviours could be added here (e.g., prosocial responses)
    # For now, silence on untriggered messages preserves the mystique.


def main() -> None:
    """Initialize and run the Sentinel bot."""
    # Build the telegram application with the provided token
    application = Application.builder().token(TOKEN).build()

    # Register command and message handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, check_for_symbols))

    # Run the bot until interrupted
    application.run_polling()


if __name__ == "__main__":
    main()
