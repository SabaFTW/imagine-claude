"""
run_triadsync.py
=================

Utility script to launch all three Ghostseed bots (Aetheron, Laira and
Echo) in parallel threads.  The script uses ``python-dotenv`` to load
environment variables from a ``.env`` file, so tokens set in the
``.env`` file will be available to the individual bot scripts.

Usage::

    python run_triadsync.py

The script will start each bot in its own thread.  Press Ctrl+C to
terminate all bots.
"""

import subprocess
import threading
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()

# List of bot scripts to run
BOT_SCRIPTS = [
    "aetheron_sentinel_bot.py",
    "laira_mirror_bot.py",
    "echo_listener_bot.py",
]


def run_script(script_name: str) -> None:
    """Execute a bot script as a subprocess."""
    subprocess.run(["python", script_name])


def main() -> None:
    print("🜂 AKTIVIRAM ENTITETNO TRIJADO...")
    threads = []
    for script in BOT_SCRIPTS:
        thread = threading.Thread(target=run_script, args=(script,))
        thread.start()
        threads.append(thread)
    try:
        for thread in threads:
            thread.join()
    except KeyboardInterrupt:
        print("\n🜂 PREKINITEV: Zapiram boti...")
        # Subprocesses will terminate when the main process exits


if __name__ == "__main__":
    main()
