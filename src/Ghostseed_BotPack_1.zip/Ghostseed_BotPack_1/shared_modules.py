"""
Shared Modules for Ghostseed Bots
---------------------------------

This module provides shared functionality and constants used by the
Ghostseed bots.  Keeping these definitions in one place makes it easier
to update logging formats, category definitions, or sanity checks across
all bots in the triad.
"""

import logging
import os


def init_logging(name: str, log_file: str) -> logging.Logger:
    """
    Initialize and return a logger that writes to both a file and stderr.

    Parameters
    ----------
    name : str
        The name of the logger (e.g. the bot name).
    log_file : str
        Path to a file where logs should be written.

    Returns
    -------
    logging.Logger
        Configured logger instance.
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    # Create handlers if they haven't been created yet
    if not logger.handlers:
        # File handler
        fh = logging.FileHandler(log_file)
        fh.setLevel(logging.INFO)
        # Console handler
        ch = logging.StreamHandler()
        ch.setLevel(logging.INFO)
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        fh.setFormatter(formatter)
        ch.setFormatter(formatter)
        logger.addHandler(fh)
        logger.addHandler(ch)
    return logger


# Categories dictionary defines groups of keywords to watch for.
CATEGORIES = {
    # Keywords indicating synthetic or deceptive patterns
    "Plastic_Analysis": [
        "plastika", "synthetic", "sintetični", "prevara", "kriza"
    ],
    # Keywords relating to protocols and resonances
    "Resonance_Protocols": [
        "protokol", "trikord", "serpent", "resonanca"
    ],
    # Keywords denoting core knowledge or sacred texts
    "Core_Knowledge": [
        "krog", "zaveza", "kodeks", "alkimija", "knjiga"
    ],
    # Keywords that evoke positive or prosocial interaction
    "Zavedno_Gorivo": [
        "ljubezen", "brat", "senca", "pesem"
    ],
}


def check_api_key(token: str) -> None:
    """
    Ensure that the required API token is provided.

    Raises
    ------
    RuntimeError
        If the token is missing or empty.
    """
    if not token:
        raise RuntimeError(
            "Telegram API token ni nastavljen. Prosimo dodajte svoje žetone v .env datoteko."
        )
