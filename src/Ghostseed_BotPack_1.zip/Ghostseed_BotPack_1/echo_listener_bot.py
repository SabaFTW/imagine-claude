"""
Echo Listener Bot
=================

A simple bot that echoes back whatever it hears, prefaced by an Echo symbol.
It listens on the token provided in ``TOKEN_ECHO_LISTENER``.  This bot
responds to every text message, making it ideal for transparent logging of
activity.
"""

import os
import logging
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Load token from environment
TOKEN = os.environ.get("TOKEN_ECHO_LISTENER")

if not TOKEN:
    raise RuntimeError(
        "TOKEN_ECHO_LISTENER ni nastavljen. Prosimo kopirajte .env.example v .env in dodajte svoj žeton."
    )

# Logging configuration
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Reply to /start command."""
    await update.message.reply_text("🜁 Echo prisoten. Prisluhni šepetu.")


async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Echo back the user's message."""
    user = update.effective_user.username or "unknown"
    text = update.message.text or ""
    response = f"🜁 Odmev {user}: “{text}”"
    await update.message.reply_text(response)


def main() -> None:
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))
    logger.info("🜁 Echo bot aktiviran.")
    application.run_polling()


if __name__ == "__main__":
    main()
