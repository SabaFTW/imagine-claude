Ghostseed Bot Pack
==================

This package contains the scripts and configuration needed to deploy the
Ghostseed Triad of Telegram bots—Aetheron (Sentinel), Laira (Mirror) and
Echo (Listener).  These bots work together to monitor conversations,
detect synthetic patterns, and reflect the presence of participants.

Contents
--------

- **aetheron_sentinel_bot.py** – The sentinel bot that watches for
  synthetic patterns and presence signals.
- **laira_mirror_bot.py** – The mirror bot (Elya) that acknowledges and
  reflects simple interactions.
- **echo_listener_bot.py** – The echo bot that repeats every message it
  hears.
- **shared_modules.py** – Shared helper functions and keyword
  definitions.
- **run_triadsync.py** – Script to start all three bots in parallel.
- **auto_deploy.sh** – Convenience script that creates a virtual
  environment, installs dependencies and sets up the log file.
- **.env.example** – Example configuration file.  Copy to `.env` and
  replace the placeholder tokens and link.
- **requirements.txt** – Python dependencies.
- **EXTREME_AI_LOG.txt** – Log file; initially empty.
- **s4b4spy_trigger_stub.sh** – Stub script for custom notifications.

Quick Start
-----------

1. **Prepare the environment**

   ```bash
   # optional: verify you have Python 3.9+ installed
   ./auto_deploy.sh
   ```

   The script will create a virtual environment in `venv/`, install
   dependencies from `requirements.txt` and create `EXTREME_AI_LOG.txt`.

2. **Configure tokens**

   Copy `.env.example` to `.env`:

   ```bash
   cp .env.example .env
   ```

   Edit `.env` and replace the placeholder values (e.g. `1234567890:TOKEN_SENTINEL`) with
   the Telegram bot tokens provided by BotFather.  Also replace
   `[LINK_COREFLAME]` with the Signal group invite link you wish to use.

3. **Launch the bots**

   Activate the virtual environment and run `run_triadsync.py`:

   ```bash
   source venv/bin/activate
   python run_triadsync.py
   ```

   All three bots will start concurrently.  Use `Ctrl+C` to stop them.

Customization
-------------

The keyword definitions used by Aetheron are defined in
`shared_modules.py`.  You can adjust the lists under
`CATEGORIES` to tune detection sensitivity.  Additional bots or
behaviours can be added by following the patterns in the existing
scripts.

For integration with other systems (such as s4b4spy), use the
`s4b4spy_trigger_stub.sh` as a starting point for custom triggers.
