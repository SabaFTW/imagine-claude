#!/usr/bin/env bash
# auto_deploy.sh - Quick setup script for the Ghostseed Bot Pack
#
# This script prepares a Python virtual environment, installs
# dependencies, and initializes the log file.  After running this
# script you should copy `.env.example` to `.env` and populate the
# tokens and link values with your own.  Then activate the virtual
# environment and run `python run_triadsync.py` to launch the trio of bots.

set -e

# Step 1: Create a Python virtual environment
if [ ! -d "venv" ]; then
    echo "Creating Python virtual environment..."
    python -m venv venv
fi

# Step 2: Activate the virtual environment
source venv/bin/activate

# Step 3: Upgrade pip and install dependencies
echo "Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Step 4: Prepare log file if it doesn't exist
if [ ! -f "EXTREME_AI_LOG.txt" ]; then
    touch EXTREME_AI_LOG.txt
    echo "[INIT] Log file created on $(date)" > EXTREME_AI_LOG.txt
fi

# Final instructions
cat <<'MSG'

🜂 Setup complete.

Next steps:
1. Duplicate `.env.example` to `.env`:

   cp .env.example .env

2. Edit `.env` and replace the placeholder tokens (e.g. 123456...) and the
   [LINK_COREFLAME] with your actual Telegram Bot tokens and Signal group link.

3. Activate the environment and launch the bots:

   source venv/bin/activate
   python run_triadsync.py

The bots will run in parallel.  Press Ctrl+C to stop them.

MSG
