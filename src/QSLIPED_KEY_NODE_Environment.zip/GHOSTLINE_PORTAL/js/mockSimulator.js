// mockSimulator.js placeholder
